import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';

const EMPTY = { name: '', description: '', category: '', address: '', city: '', state: '', pincode: '', phone: '', email: '', website: '' };

export default function BusinessForm() {
  const { id } = useParams();
  const editing = !!id;
  const { user } = useAuth();
  const navigate = useNavigate();
  const [f, setF] = useState(EMPTY);
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get('/categories').then((r) => setCategories(r.data)).catch((e) => setError(errMsg(e)));
    if (editing) {
      api.get(`/businesses/${id}`)
        .then(({ data: b }) => setF({
          name: b.name, description: b.description, category: b.category?._id || '',
          address: b.location.address, city: b.location.city, state: b.location.state || '', pincode: b.location.pincode || '',
          phone: b.contact.phone, email: b.contact.email || '', website: b.website || '',
        }))
        .catch((e) => setError(errMsg(e)));
    }
  }, [id, editing]);

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    const payload = {
      name: f.name, description: f.description, category: f.category, website: f.website,
      location: { address: f.address, city: f.city, state: f.state, pincode: f.pincode },
      contact: { phone: f.phone, email: f.email },
    };
    try {
      if (editing) await api.put(`/businesses/${id}`, payload);
      else await api.post('/businesses', payload);
      const notice = user.role === 'admin'
        ? 'Listing saved and published.'
        : 'Listing saved. It will appear in the directory once an admin approves it.';
      navigate('/dashboard', { state: { notice } });
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  };

  return (
    <div className="page narrow">
      <h1>{editing ? 'Edit listing' : 'Add a listing'}</h1>
      <form onSubmit={submit} className="form">
        <label>Business name<input value={f.name} onChange={set('name')} required maxLength={100} /></label>
        <label>
          Category
          <select value={f.category} onChange={set('category')} required>
            <option value="">Choose a category</option>
            {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
          </select>
        </label>
        <label>
          Description
          <textarea rows={4} value={f.description} onChange={set('description')} required maxLength={1000} />
        </label>
        <label>Street address<input value={f.address} onChange={set('address')} required /></label>
        <div className="grid3">
          <label>City<input value={f.city} onChange={set('city')} required /></label>
          <label>State<input value={f.state} onChange={set('state')} /></label>
          <label>PIN code<input value={f.pincode} onChange={set('pincode')} inputMode="numeric" /></label>
        </div>
        <div className="grid2">
          <label>Phone<input type="tel" value={f.phone} onChange={set('phone')} required /></label>
          <label>Contact email<input type="email" value={f.email} onChange={set('email')} /></label>
        </div>
        <label>Website<input value={f.website} onChange={set('website')} placeholder="example.com" /></label>
        {error && <p className="alert alert-error">{error}</p>}
        <div className="actions">
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : editing ? 'Save changes' : 'Add listing'}</button>
          <Link to="/dashboard" className="btn btn-ghost">Cancel</Link>
        </div>
      </form>
    </div>
  );
}
