import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import StatusBadge from '../components/StatusBadge';
import { hostOf } from '../components/BusinessEntry';

export default function BusinessDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [b, setB] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    setB(null);
    api.get(`/businesses/${id}`).then((r) => setB(r.data)).catch((e) => setError(errMsg(e)));
  }, [id, user]);

  if (error) return <div className="page narrow"><h1>Business not found</h1><p>{error}</p><Link to="/">Back to the directory</Link></div>;
  if (!b) return <p className="page muted">Loading…</p>;

  const canManage = user && (user.role === 'admin' || b.owner?._id === user.id);
  const { address, city, state, pincode } = b.location;
  const fullAddress = [address, city, [state, pincode].filter(Boolean).join(' ')].filter(Boolean).join(', ');

  const remove = async () => {
    if (!window.confirm(`Delete “${b.name}” permanently?`)) return;
    try { await api.delete(`/businesses/${b._id}`); navigate('/dashboard'); } catch (e) { setError(errMsg(e)); }
  };

  return (
    <div className="page detail">
      <article>
        <Link to="/" className="back">Back to results</Link>
        <p className="entry-cat">{b.category?.name}</p>
        <h1>{b.name}</h1>
        {b.status !== 'approved' && <p><StatusBadge status={b.status} /></p>}
        <p className="detail-desc">{b.description}</p>
        <p className="muted small">Listed by {b.owner?.name}</p>
        {canManage && (
          <div className="actions">
            <Link to={`/business/${b._id}/edit`} className="btn btn-ghost">Edit listing</Link>
            <button className="btn btn-danger" onClick={remove}>Delete listing</button>
          </div>
        )}
      </article>

      <aside className="sheet">
        <h2>Contact</h2>
        <dl>
          <dt>Phone</dt>
          <dd><a href={`tel:${b.contact.phone.replace(/\s/g, '')}`}>{b.contact.phone}</a></dd>
          {b.contact.email && (<><dt>Email</dt><dd><a href={`mailto:${b.contact.email}`}>{b.contact.email}</a></dd></>)}
          {b.website && (<><dt>Website</dt><dd><a href={b.website} target="_blank" rel="noreferrer">{hostOf(b.website)}</a></dd></>)}
          <dt>Address</dt>
          <dd>{fullAddress}</dd>
        </dl>
        <a
          className="btn btn-accent"
          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${b.name}, ${fullAddress}`)}`}
          target="_blank"
          rel="noreferrer"
        >
          Open in Google Maps
        </a>
      </aside>
    </div>
  );
}
