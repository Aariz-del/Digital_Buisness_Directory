import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import api, { errMsg } from '../api';
import StatusBadge from '../components/StatusBadge';

export default function Dashboard() {
  const { state } = useLocation();
  const [items, setItems] = useState(null);
  const [error, setError] = useState('');

  const load = () => api.get('/businesses/mine').then((r) => setItems(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  const remove = async (b) => {
    if (!window.confirm(`Delete “${b.name}” permanently?`)) return;
    try { await api.delete(`/businesses/${b._id}`); load(); } catch (e) { setError(errMsg(e)); }
  };

  return (
    <div className="page">
      <div className="page-head">
        <h1>My listings</h1>
        <Link to="/business/new" className="btn btn-primary">Add a listing</Link>
      </div>
      {state?.notice && <p className="alert alert-ok">{state.notice}</p>}
      {error && <p className="alert alert-error">{error}</p>}

      {items && items.length === 0 && (
        <div className="empty">
          <h2>You haven't listed a business yet</h2>
          <p>Add your first listing and it will go to an admin for approval.</p>
        </div>
      )}

      {items && items.length > 0 && (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Business</th><th>Category</th><th>City</th><th>Status</th><th /></tr></thead>
            <tbody>
              {items.map((b) => (
                <tr key={b._id}>
                  <td><Link to={`/business/${b._id}`}>{b.name}</Link></td>
                  <td>{b.category?.name}</td>
                  <td>{b.location.city}</td>
                  <td><StatusBadge status={b.status} /></td>
                  <td className="row-actions">
                    <Link to={`/business/${b._id}/edit`} className="btn btn-ghost btn-sm">Edit</Link>
                    <button className="btn btn-danger btn-sm" onClick={() => remove(b)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
