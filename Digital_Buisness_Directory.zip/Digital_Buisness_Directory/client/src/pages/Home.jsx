import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';

export default function Home() {
  const [businesses, setBusinesses] = useState([]);
  const [cities, setCities] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedCity, setSelectedCity] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [bizRes, catRes, cityRes] = await Promise.all([
          api.get(`/businesses?search=${search}&category=${selectedCategory}&city=${selectedCity}`),
          api.get('/categories').catch(() => ({ data: { data: [] } })),
          api.get('/businesses/cities').catch(() => ({ data: { data: [] } }))
        ]);

        setBusinesses(bizRes.data.data || bizRes.data || []);
        setCategories(catRes.data.data || catRes.data || []);
        setCities(cityRes.data.data || cityRes.data || []);
      } catch (err) {
        setError(errMsg(err));
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [search, selectedCategory, selectedCity]);

  return (
    <div className="home-container">
      <h1>Browse Local Businesses</h1>
      {error && <div className="alert alert-danger">{error}</div>}

      <div className="filters-bar">
        <input
          type="text"
          placeholder="Search businesses..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select value={selectedCity} onChange={(e) => setSelectedCity(e.target.value)}>
          <option value="">All Cities</option>
          {Array.isArray(cities) && cities.map((city, idx) => (
            <option key={idx} value={city}>{city}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="business-grid">
          {Array.isArray(businesses) && businesses.length > 0 ? (
            businesses.map((biz) => (
              <div key={biz._id} className="card">
                <h3>{biz.name}</h3>
                <p>{biz.description}</p>
                <Link to={`/business/${biz._id}`} className="btn btn-sm btn-primary">View Details</Link>
              </div>
            ))
          ) : (
            <p>No businesses found. Make sure to run `npm run seed` in your server folder!</p>
          )}
        </div>
      )}
    </div>
  );
}