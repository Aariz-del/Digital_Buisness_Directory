import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import StatusBadge from '../components/StatusBadge';

function Listings({ onChange }) {
  const [status, setStatus] = useState('pending');
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');

  const load = useCallback(
    () => api.get('/businesses/all', { params: { status } }).then((r) => setItems(r.data)).catch((e) => setError(errMsg(e))),
    [status]
  );
  useEffect(() => { load(); }, [load]);

  const run = async (fn) => {
    try { await fn(); await load(); onChange(); } catch (e) { setError(errMsg(e)); }
  };
  const setS = (id, s) => run(() => api.patch(`/businesses/${id}/status`, { status: s }));
  const del = (b) => window.confirm(`Delete “${b.name}” permanently?`) && run(() => api.delete(`/businesses/${b._id}`));

  return (
    <>
      <div className="toolbar">
        <label>Show
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="pending">Pending review</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
            <option value="">All listings</option>
          </select>
        </label>
      </div>
      {error && <p className="alert alert-error">{error}</p>}
      {items.length === 0 ? (
        <div className="empty"><h2>Nothing here</h2><p>No listings have this status.</p></div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Business</th><th>Owner</th><th>City</th><th>Status</th><th /></tr></thead>
            <tbody>
              {items.map((b) => (
                <tr key={b._id}>
                  <td><Link to={`/business/${b._id}`}>{b.name}</Link><div className="muted small">{b.category?.name}</div></td>
                  <td>{b.owner?.name}<div className="muted small">{b.owner?.email}</div></td>
                  <td>{b.location.city}</td>
                  <td><StatusBadge status={b.status} /></td>
                  <td className="row-actions">
                    {b.status !== 'approved' && <button className="btn btn-primary btn-sm" onClick={() => setS(b._id, 'approved')}>Approve</button>}
                    {b.status !== 'rejected' && <button className="btn btn-ghost btn-sm" onClick={() => setS(b._id, 'rejected')}>Reject</button>}
                    <button className="btn btn-danger btn-sm" onClick={() => del(b)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}

function Categories({ onChange }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', description: '' });
  const [editing, setEditing] = useState(null); // {_id, name, description}
  const [error, setError] = useState('');

  const load = () => api.get('/categories').then((r) => setItems(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  const run = async (fn) => {
    setError('');
    try { await fn(); await load(); onChange(); } catch (e) { setError(errMsg(e)); }
  };
  const add = (e) => { e.preventDefault(); run(async () => { await api.post('/categories', form); setForm({ name: '', description: '' }); }); };
  const save = () => run(async () => { await api.put(`/categories/${editing._id}`, editing); setEditing(null); });
  const del = (c) => window.confirm(`Delete the “${c.name}” category?`) && run(() => api.delete(`/categories/${c._id}`));

  return (
    <>
      <form className="inline-form" onSubmit={add}>
        <input placeholder="Category name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <input placeholder="Short description (optional)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <button className="btn btn-primary">Add category</button>
      </form>
      {error && <p className="alert alert-error">{error}</p>}
      <div className="table-wrap">
        <table className="table">
          <thead><tr><th>Name</th><th>Description</th><th /></tr></thead>
          <tbody>
            {items.map((c) => (
              <tr key={c._id}>
                {editing?._id === c._id ? (
                  <>
                    <td><input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></td>
                    <td><input value={editing.description || ''} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></td>
                    <td className="row-actions">
                      <button className="btn btn-primary btn-sm" onClick={save}>Save</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => setEditing(null)}>Cancel</button>
                    </td>
                  </>
                ) : (
                  <>
                    <td>{c.name}</td>
                    <td className="muted">{c.description}</td>
                    <td className="row-actions">
                      <button className="btn btn-ghost btn-sm" onClick={() => setEditing(c)}>Edit</button>
                      <button className="btn btn-danger btn-sm" onClick={() => del(c)}>Delete</button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function Users({ onChange }) {
  const { user: me } = useAuth();
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');

  const load = () => api.get('/admin/users').then((r) => setItems(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  const run = async (fn) => {
    setError('');
    try { await fn(); await load(); onChange(); } catch (e) { setError(errMsg(e)); }
  };
  const setRole = (u, role) => run(() => api.patch(`/admin/users/${u._id}/role`, { role }));
  const del = (u) => window.confirm(`Delete ${u.name} and all of their listings?`) && run(() => api.delete(`/admin/users/${u._id}`));

  return (
    <>
      {error && <p className="alert alert-error">{error}</p>}
      <div className="table-wrap">
        <table className="table">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th /></tr></thead>
          <tbody>
            {items.map((u) => (
              <tr key={u._id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>
                  <select value={u.role} disabled={u._id === me.id} onChange={(e) => setRole(u, e.target.value)} aria-label={`Role for ${u.name}`}>
                    <option value="user">User</option>
                    <option value="owner">Owner</option>
                    <option value="admin">Admin</option>
                  </select>
                </td>
                <td className="row-actions">
                  <button className="btn btn-danger btn-sm" disabled={u._id === me.id} onClick={() => del(u)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default function Admin() {
  const [tab, setTab] = useState('listings');
  const [stats, setStats] = useState(null);
  const [tick, setTick] = useState(0);

  useEffect(() => { api.get('/admin/stats').then((r) => setStats(r.data)).catch(() => {}); }, [tick]);
  const refresh = () => setTick((t) => t + 1);

  const tiles = stats && [
    ['Pending review', stats.businesses.pending],
    ['Approved listings', stats.businesses.approved],
    ['Rejected', stats.businesses.rejected],
    ['Categories', stats.categories],
    ['Users', stats.users],
  ];

  return (
    <div className="page">
      <h1>Admin</h1>
      {tiles && (
        <dl className="stats">
          {tiles.map(([label, n]) => (
            <div key={label}><dd>{n}</dd><dt>{label}</dt></div>
          ))}
        </dl>
      )}
      <div className="tabs" role="tablist">
        {[['listings', 'Listings'], ['categories', 'Categories'], ['users', 'Users']].map(([k, label]) => (
          <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{label}</button>
        ))}
      </div>
      {tab === 'listings' && <Listings onChange={refresh} />}
      {tab === 'categories' && <Categories onChange={refresh} />}
      {tab === 'users' && <Users onChange={refresh} />}
    </div>
  );
}
