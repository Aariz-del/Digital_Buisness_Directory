import { Link } from 'react-router-dom';

export const hostOf = (url) => {
  try { return new URL(url).host.replace(/^www\./, ''); } catch { return url; }
};

export default function BusinessEntry({ b }) {
  const place = [b.location.city, b.location.state].filter(Boolean).join(', ');
  return (
    <Link to={`/business/${b._id}`} className="entry">
      <div className="entry-main">
        <h3>{b.name}</h3>
        <p className="entry-cat">{b.category?.name}</p>
        <p className="entry-desc">{b.description}</p>
      </div>
      <div className="entry-meta">
        <span>{place}</span>
        <span>{b.contact.phone}</span>
        {b.website && <span className="muted">{hostOf(b.website)}</span>}
      </div>
    </Link>
  );
}
