const LABELS = { pending: 'Pending review', approved: 'Approved', rejected: 'Rejected' };

export default function StatusBadge({ status }) {
  return <span className={`badge badge-${status}`}>{LABELS[status] || status}</span>;
}
