import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="nav">
      <Link to="/" className="brand">
        <span className="brand-mark" aria-hidden="true" />
        LocalList
      </Link>
      <nav>
        <NavLink to="/" end>Browse</NavLink>
        {user && ['owner', 'admin'].includes(user?.role) && <NavLink to="/dashboard">My listings</NavLink>}
        {user?.role === 'admin' && <NavLink to="/admin">Admin</NavLink>}
        {user ? (
          <>
            <span className="nav-user">{user.name}</span>
            <button className="btn btn-ghost btn-sm" onClick={handleLogout}>Log out</button>
          </>
        ) : (
          <>
            <NavLink to="/login">Log in</NavLink>
            <Link to="/register" className="btn btn-accent btn-sm">Sign up</Link>
          </>
        )}
      </nav>
    </header>
  );
}