import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
  withCredentials: true,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const errMsg = (err) => {
  return err.response && err.response.data && err.response.data.message
    ? err.response.data.message
    : err.message;
};

export default api;