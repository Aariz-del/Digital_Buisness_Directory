const mongoose = require('mongoose');

const addProtocol = (v) => (v && !/^https?:\/\//i.test(v) ? `https://${v}` : v);

const businessSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, 'Business name is required'], trim: true, maxlength: 100 },
    description: { type: String, required: [true, 'Description is required'], trim: true, maxlength: 1000 },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: [true, 'Category is required'] },
    location: {
      address: { type: String, required: [true, 'Address is required'], trim: true },
      city: { type: String, required: [true, 'City is required'], trim: true },
      state: { type: String, trim: true },
      pincode: { type: String, trim: true },
    },
    contact: {
      phone: { type: String, required: [true, 'Phone number is required'], trim: true },
      email: { type: String, lowercase: true, trim: true, match: [/^$|^\S+@\S+\.\S+$/, 'Enter a valid contact email'] },
    },
    website: { type: String, trim: true, set: addProtocol },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true }
);

businessSchema.index({ status: 1, createdAt: -1 });
businessSchema.index({ 'location.city': 1 });

module.exports = mongoose.model('Business', businessSchema);
