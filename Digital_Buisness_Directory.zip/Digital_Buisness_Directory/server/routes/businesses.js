const express = require('express');
const {
  getBusinesses,
  getBusiness,
  getCities,
  createBusiness,
  updateBusiness,
  deleteBusiness
} = require('../controllers/businessController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/cities').get(getCities);

router
  .route('/')
  .get(getBusinesses)
  .post(protect, authorize('owner', 'admin'), createBusiness);

router
  .route('/:id')
  .get(getBusiness)
  .put(protect, authorize('owner', 'admin'), updateBusiness)
  .delete(protect, authorize('owner', 'admin'), deleteBusiness);

module.exports = router;