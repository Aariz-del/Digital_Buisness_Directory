const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect, authorize('admin'));

router.get('/stats', ctrl.stats);
router.get('/users', ctrl.users);
router.patch('/users/:id/role', ctrl.setRole);
router.delete('/users/:id', ctrl.removeUser);

module.exports = router;
