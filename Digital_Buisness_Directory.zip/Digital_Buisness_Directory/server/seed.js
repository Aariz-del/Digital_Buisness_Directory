// Usage: npm run seed   (WARNING: clears users, categories and businesses first)
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');
const Category = require('./models/Category');
const Business = require('./models/Business');

const businesses = [
  ['Saffron Table', 'Restaurants', 'Family-run North Indian kitchen known for slow-cooked dals and tandoor breads. Lunch thali until 3 pm.', '12 Banjara Heights, Road No. 4', 'Hyderabad', 'Telangana', '500034', '+91 40 5550 1101', 'hello@saffrontable.example', 'saffrontable.example'],
  ['Green Leaf Cafe', 'Restaurants', 'Vegetarian cafe with filter coffee, millet bowls and a small reading shelf.', '48 Residency Road', 'Bengaluru', 'Karnataka', '560025', '+91 80 5550 2202', 'cafe@greenleaf.example', 'greenleaf.example'],
  ['CityCare Clinic', 'Healthcare', 'General physicians, paediatrics and a walk-in pharmacy. Open Monday to Saturday, 8 am to 9 pm.', '7 Linking Road, Bandra West', 'Mumbai', 'Maharashtra', '400050', '+91 22 5550 3303', 'frontdesk@citycare.example', 'citycare.example'],
  ['Smile Studio Dental', 'Healthcare', 'Preventive dentistry, aligners and same-day crowns with digital scanning.', '23 Anna Salai', 'Chennai', 'Tamil Nadu', '600002', '+91 44 5550 4404', 'book@smilestudio.example', 'smilestudio.example'],
  ['BrightPath Tutors', 'Education', 'Small-batch maths and science coaching for classes 8 to 12, with weekly progress reports.', '5 Jubilee Hills Check Post', 'Hyderabad', 'Telangana', '500033', '+91 40 5550 5505', 'admissions@brightpath.example', 'brightpath.example'],
  ['CodeNest Academy', 'Education', 'Weekend web development and data courses taught by working engineers.', '101 Koramangala 5th Block', 'Bengaluru', 'Karnataka', '560095', '+91 80 5550 6606', 'learn@codenest.example', 'codenest.example'],
  ['Urban Threads', 'Retail', 'Independent clothing store stocking handloom cotton, linen and made-to-measure kurtas.', '14 Connaught Place, Block F', 'New Delhi', 'Delhi', '110001', '+91 11 5550 7707', 'shop@urbanthreads.example', 'urbanthreads.example'],
  ['Book Barn', 'Retail', 'Secondhand and new books, board games, and a Sunday storytelling hour for kids.', '9 MG Road', 'Pune', 'Maharashtra', '411001', '+91 20 5550 8808', 'hello@bookbarn.example', ''],
  ['FixIt Home Services', 'Home Services', 'Electricians, plumbers and carpenters with fixed price quotes and a 30-day work guarantee.', '33 Gachibowli Main Road', 'Hyderabad', 'Telangana', '500032', '+91 40 5550 9909', 'support@fixit.example', 'fixit.example'],
  ['PulseFit Gym', 'Fitness', 'Strength floor, group classes and personal training. Day passes available.', '88 Indiranagar 100 Feet Road', 'Bengaluru', 'Karnataka', '560038', '+91 80 5550 1010', 'join@pulsefit.example', 'pulsefit.example'],
];

(async () => {
  await connectDB();
  await Promise.all([User.deleteMany(), Category.deleteMany(), Business.deleteMany()]);

  const [admin, owner] = await User.create([
    { name: 'Admin', email: 'admin@example.com', password: 'admin123', role: 'admin' },
    { name: 'Olivia Owner', email: 'owner@example.com', password: 'owner123', role: 'owner' },
    { name: 'Uma User', email: 'user@example.com', password: 'user123', role: 'user' },
  ]);

  const names = [...new Set(businesses.map((b) => b[1]))];
  const cats = await Category.create(names.map((name) => ({ name })));
  const catId = Object.fromEntries(cats.map((c) => [c.name, c._id]));

  await Business.create(
    businesses.map(([name, cat, description, address, city, state, pincode, phone, email, website], i) => ({
      name, description, category: catId[cat], website,
      location: { address, city, state, pincode },
      contact: { phone, email },
      owner: i % 2 === 0 ? owner._id : admin._id,
      status: 'approved',
    }))
  );

  // One pending listing so the moderation queue is not empty
  await Business.create({
    name: 'Lotus Spa & Wellness', description: 'Ayurvedic massage and wellness packages. Awaiting approval.',
    category: catId['Fitness'], location: { address: '2 Beach Road', city: 'Chennai', state: 'Tamil Nadu', pincode: '600001' },
    contact: { phone: '+91 44 5550 1212' }, owner: owner._id, status: 'pending',
  });

  console.log('Seeded. Logins: admin@example.com / admin123, owner@example.com / owner123, user@example.com / user123');
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
