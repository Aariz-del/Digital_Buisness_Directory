const Business = require('../models/Business');
const asyncHandler = require('../middleware/async');

// @desc    Get all businesses
exports.getBusinesses = asyncHandler(async (req, res, next) => {
  try {
    let queryObj = { status: 'approved' };

    if (req.query.search) {
      queryObj.$or = [
        { name: { $regex: req.query.search, $options: 'i' } },
        { description: { $regex: req.query.search, $options: 'i' } },
        { 'location.city': { $regex: req.query.search, $options: 'i' } },
        { 'location.address': { $regex: req.query.search, $options: 'i' } }
      ];
    }
    if (req.query.category) {
      queryObj.category = req.query.category;
    }
    if (req.query.city) {
      queryObj['location.city'] = req.query.city;
    }

    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 8;
    const startIndex = (page - 1) * limit;
    
    const total = await Business.countDocuments(queryObj).catch(() => 0);
    const businesses = await Business.find(queryObj)
      .populate('category', 'name')
      .skip(startIndex)
      .limit(limit)
      .catch(() => []);

    res.status(200).json({
      success: true,
      count: businesses.length,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit) || 1
      },
      data: businesses
    });
  } catch (err) {
    res.status(200).json({ success: true, count: 0, pagination: { page: 1, limit: 8, total: 0, pages: 1 }, data: [] });
  }
});

// @desc    Get single business
exports.getBusiness = asyncHandler(async (req, res, next) => {
  const business = await Business.findById(req.params.id).populate('category', 'name');
  if (!business) {
    return res.status(404).json({ message: `Business not found with id of ${req.params.id}` });
  }
  res.status(200).json({ success: true, data: business });
});

// @desc    Get unique cities
exports.getCities = asyncHandler(async (req, res, next) => {
  try {
    const cities = await Business.distinct('location.city', { status: 'approved' });
    res.status(200).json({ success: true, data: cities || [] });
  } catch (err) {
    res.status(200).json({ success: true, data: [] });
  }
});

// @desc    Create new business
exports.createBusiness = asyncHandler(async (req, res, next) => {
  req.body.user = req.user.id;
  req.body.status = req.user.role === 'admin' ? 'approved' : 'pending';
  const business = await Business.create(req.body);
  res.status(201).json({ success: true, data: business });
});

// @desc    Update business
exports.updateBusiness = asyncHandler(async (req, res, next) => {
  let business = await Business.findById(req.params.id);
  if (!business) {
    return res.status(404).json({ message: `Business not found with id of ${req.params.id}` });
  }
  if (business.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return res.status(401).json({ message: 'Not authorized to update this business' });
  }
  if (req.user.role !== 'admin') {
    req.body.status = 'pending';
  }
  business = await Business.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });
  res.status(200).json({ success: true, data: business });
});

// @desc    Delete business
exports.deleteBusiness = asyncHandler(async (req, res, next) => {
  const business = await Business.findById(req.params.id);
  if (!business) {
    return res.status(404).json({ message: `Business not found with id of ${req.params.id}` });
  }
  if (business.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return res.status(401).json({ message: 'Not authorized to delete this business' });
  }
  await business.deleteOne();
  res.status(200).json({ success: true, data: {} });
});