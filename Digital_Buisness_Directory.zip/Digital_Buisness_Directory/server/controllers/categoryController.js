const asyncHandler = require('../middleware/async');
const Category = require('../models/Category');
const Business = require('../models/Business');

const fields = (b) => ({ name: b.name, description: b.description });

exports.list = asyncHandler(async (req, res) => {
  res.json(await Category.find().sort('name'));
});

exports.create = asyncHandler(async (req, res) => {
  res.status(201).json(await Category.create(fields(req.body)));
});

exports.update = asyncHandler(async (req, res) => {
  const cat = await Category.findByIdAndUpdate(req.params.id, fields(req.body), { new: true, runValidators: true });
  if (!cat) return res.status(404).json({ message: 'Category not found' });
  res.json(cat);
});

exports.remove = asyncHandler(async (req, res) => {
  const inUse = await Business.countDocuments({ category: req.params.id });
  if (inUse) return res.status(409).json({ message: `This category is used by ${inUse} listing(s). Move them first` });
  const cat = await Category.findByIdAndDelete(req.params.id);
  if (!cat) return res.status(404).json({ message: 'Category not found' });
  res.json({ message: 'Category deleted' });
});
