const asyncHandler = require('../middleware/async');
const User = require('../models/User');
const Business = require('../models/Business');
const Category = require('../models/Category');

// GET /api/admin/stats
exports.stats = asyncHandler(async (req, res) => {
  const [users, categories, grouped] = await Promise.all([
    User.countDocuments(),
    Category.countDocuments(),
    Business.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
  ]);
  const businesses = { pending: 0, approved: 0, rejected: 0 };
  grouped.forEach((g) => { businesses[g._id] = g.count; });
  res.json({ users, categories, businesses });
});

// GET /api/admin/users
exports.users = asyncHandler(async (req, res) => {
  res.json(await User.find().sort('-createdAt'));
});

// PATCH /api/admin/users/:id/role
exports.setRole = asyncHandler(async (req, res) => {
  const { role } = req.body;
  if (!['user', 'owner', 'admin'].includes(role)) return res.status(400).json({ message: 'Invalid role' });
  if (String(req.user._id) === req.params.id) return res.status(400).json({ message: 'You cannot change your own role' });
  const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true });
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
});

// DELETE /api/admin/users/:id  (also removes the user's listings)
exports.removeUser = asyncHandler(async (req, res) => {
  if (String(req.user._id) === req.params.id) return res.status(400).json({ message: 'You cannot delete your own account' });
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
  await Business.deleteMany({ owner: user._id });
  res.json({ message: 'User and their listings deleted' });
});
